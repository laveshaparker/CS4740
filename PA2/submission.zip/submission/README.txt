Sofonias Assefa (saa237)
La Vesha Parker (ldp47)

To run our QA system,

Enter the following into the command window:
	python answer_formation.py <'dev' or 'test' as an argument>

	For test set, run:
		'python answer_formation.py test'

	For dev set, run:
		'python answer_formation.py dev'

	This will output a file name output.txt which contains our responses.

Please note that our code requires Python 3.4., nltk, and numpy to run.

We have also modified and included our 'evaluation.py' script to be compatible with Python 3.4.
